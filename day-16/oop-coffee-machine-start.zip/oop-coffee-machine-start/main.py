from menu import Menu, MenuItem
from coffee_maker import CoffeeMaker
from money_machine import MoneyMachine

menu_item = MenuItem()
menu = Menu()
coffe_maker = CoffeeMaker()
money_machine = MoneyMachine()

is_working = True
while is_working:
    input = input(f"What would you like? ({menu.get_items()}): ")

    if input == "off":
        break
    if input == "report":
        print(coffe_maker.report())
        print(money_machine.report())
    else:
        if menu_item:
            menu.find_drink(order_name=input)
